<?php
define('WEBDIR','/mails'); // used to reflect in which base folder under WWWROOT we are placed
define('DATABASE_HOST','localhost');
define('DATABASE_USER','postfixadmin');
define('DATABASE_PASSWORD','postfixadmin');
define('DATABASE_NAME','postfix');

$tmpdir = '/var/www/'.WEBDIR; // used to reflect where in filesystem we are placed 
?>